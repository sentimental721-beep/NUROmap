NUROmap GitHub Pages 配置手順

1. GitHubで intech-ukigai/NUROmap リポジトリを作成（公開リポジトリには業務上の機密データを入れない）。
2. index.html を配置し、Settings > Pages > Deploy from a branch > main / (root) を選ぶ。
3. Google CloudのAPIキー制限に https://intech-ukigai.github.io/NUROmap/* を登録。
4. サイトを開きAPIキーを入力して「Googleマップを表示」。
5. Geocoding APIとMaps JavaScript APIが有効か、課金設定と利用制限を確認。

注意: 判定データ.csv は業務用データのため、このZIPには含めていません。公開GitHub Pagesにアップロードすると第三者が取得できます。社内限定運用には認証付きホスティングが必要です。CSV未配置の場合、地図の表示は可能ですがエリア判定はできません。町丁目塗り分けにはGeoJSON境界データも必要です。
契約先工事枠サイトのAPIキー付きURLも公開コードに埋め込まないでください。
